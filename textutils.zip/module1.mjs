import dza, {a, c, d}  from './module2.mjs'
console.log(dza);
console.log(c);
console.log(d);
console.log(a);